[TOC]
# Week 2: Types of neural network architectures
## Feed-forward neural networks
- having the input layer, (hidden layers), the output in this ordering.
![Alt text](./1496746738102.png)
The first layer is the input and the last layer is the output. If there is more than ($\geq$) one hidden layer $\rightarrow$ **deep** neural networks.
The activities of the neurons in each layer are a non-linear function of the activities in the layer **below**.
$\rightarrow$ compute a series of transformations that change the similarities between cases. 
## Recurrent neural networks
- having additional cycles, which can come back the previous nodes from the arrows.
- different from the FFNN is that have the same weight at each time slice (one hidden layer per time slice), and each input is captured at each time slice $\rightarrow$ the output also is in each time slice.
- suitable for modeling the sequence data.
![Alt text](./1496746989088.png)
## Symmetrically connected neural networks
- like recurrent networks, but the connections between units are symmetrical (same weight in both directions).
- more restricted, since obey an energy function (?) (cannot model cycles).
- symmetrically connected nets **without** hidden units = Hopfield nets.
# Perceptron: The first generation of neural networks
## The standard Perceptron architecture
- is a particular example of a statistical pattern recognition system.
![Alt text](./1496587135616.png)
	- Convert the raw input vector into a vector of feature activation (**use hand-written programs, based common-sense to define the features**).
	- $\color{red}{Learn}$ how to weight each of the feature activations to get a single scalar quantity (feature activities $\times$ the learned weights $\rightarrow$ the sum of feature activities $\times$ learned weights = this quantity).
	- If this quantity is above (>) some threshold, decide that the input vector is a positive example of the target class. 
## Types of Perceptron neural networks
1. Binary threshold neurons (decision units)
- is also called McCulloch-Pitts.
- first, compute the weighted sum of the inputs from other neurons (plus a bias):
$$z=b+\sum_{i}x_iw_i$$
In matrix form:
$$z=b+x^Tw$$
with $b$ is a bias.
- then, output a 1 if the weighted sum exceeds zero.
$$
y=
\left\{
\begin{array}{II}
	1 & z\geq0 \\
	0 & otherwise \\
\end{array}
\right.
$$
![Alt text](./1496591911345.png)
- How to learn biases using the same rule as used for learning weights
	- the bias = the negative of the threshold ($b=-\theta$) and vice versus.
	- use the trick: a bias is exactly equivalent to a weight on an extra input line that always has an activity of 1.
![Alt text](./1496593465499.png)
- The Perceptron convergence procedure: Training binary output neurons as classifiers
	- Add an extra component with value 1 to each input vector. The _"bias" weight_ on this component = $-\theta$ (threshold).
	- Pick training cases using any policy that ensures every training case will keep getting picked without waiting too long. Then we have picked a training case with 3 options:
		- the output unit is correct $\rightarrow$ don't change the weights.
		- the output unit incorrectly outputs a zero (the output should be a 1) $\rightarrow$ **add** the input vector **to** the weight vector of perceptron.
		- the output unit incorrectly outputs a one (the output should be a 0) $\rightarrow$ **subtract** the input vector **from** the weight vector.
![Alt text](./1496595760544.png)
## A geometrical view of the perceptrons
### Weight space
- one dimension per weight.
- a point in the space represents a particular setting of all the weights. 
- **except from** the threshold (the bias weight term), each training case can be represented as a hyperplane through the origin in the weight space (mỗi mẫu training được coi như một siêu phẳng đi qua gốc tọa độ trong không gian trọng số n-chiều).
	-	the weights lie on one side of this hyper-plane to get the answer correct.
![Alt text](./1496601244960.png)
- Explanation of the above image:
	- A training case defines a plane, which is 2D in the above image (the black line). 
	- The plane goes through the origin and perpendicular to the input vector (the blue vector).
	- Consider a training case in which the correct answer is one (is 1) $\rightarrow$ the weight vector of the correct answer must to be on the correct side of the hyperplane (the same side of the hyperplane as the direction in which the training vector points) (cùng chiều với training vector chỉ đến bên nào của siêu phẳng) (in here is the green vector).
		- Any weight vector like the green one, the angle with the input vector (the blue one) will be $\leq 90^\circ \rightarrow$ the scalar product (the dot product) of the input vector and the weight vector $>0$ (since $cos(\alpha\leq90^\circ)>0$ and because of eliminating the threshold, so just compare with $0$ only).
		- Conversely for the wrong output (the output is 0) (the red vector).
- For the target correct answer is 0, we have another image like the below:
![Alt text](./1496666137811.png)
![Alt text](./1496605631496.png)
### The cone of feasible solutions
![Alt text](./1496666358049.png)
- For the above image, any weight vectors inside the cone will get the correct answer for both training cases. There doesn't have to be any cone like that (if it could be there are no weight vectors that get the right answers for all of the training cases).
- To get all training cases right, we need to find a point on the right side of all the planes. There may not be any such point.
- If there are any weight vectors that get the right answer for all cases, they lie in a hyper-cone with its **apex** at the **origin**. $\rightarrow$ the average of **two** good weight vectors is a good weight vector (is also a solution itself - also in that cone).
$\rightarrow$ the problem is convex.
![Alt text](./1496667151637.png)
![Alt text](./1496667171799.png)
![Alt text](./1496667200852.png)
![Alt text](./1496667222522.png)
### Why the learning works
- the perceptron learning procedure will get the weights into the cone of the feasible solutions (the convergence rule).
- Notation:
	- a feasible vector: a solution weight vector that get correct answer for all training cases (if these vectors exist) (is shown in the green dot in the following image).
![Alt text](./1496667962619.png)
	- start with weight vector that gets some of the training cases wrong (the red dot).
	- The idea for proof: When getting a training case wrong, the **current** weight vector will be updated to closer to every **feasible** weight vector.
	- By the way of considering the squared distance $d_a^2+d_b^2$ between the **current** weight vector and any **feasible** weight vector (the squared distance _along the line of the input vector_ that defines the training case ($d_a$) and another squared difference _orthogonal_ to that line ($d_b$)).
	- $d_b$ is not change, but $d_a$ will be gotten smaller.
$\rightarrow$ Every time the perceptron makes a mistake, the learning algo moves the **current** weight vector closer to all **feasible** weight vectors. 
- However, unfortunately, there is **feasible** weight vector is very near the black line (the golden dot), the **current** weight vector is just in the wrong side, and the input vector is quite big $\rightarrow$ adding the input vector to the count weight vector, we get the further away from that golden feasible weight vector. (we need to fix it up by the **margin** as following).
- Define the **generously feasible** weight vectors = a weight vector that not only gets every training case right, but gets it right by at least a **certain margin**.  
- The **margin** is at least as great as the length of the input vector that defines each constraint plane ($\in$ the feasible region).
- Now, we have the cone of the feasible solutions and another cone of generously feasible solutions which gets the everything right answer by at least the size of the input vector.
![Alt text](./1496669577219.png)
$\rightarrow$ Every time the perceptron makes a mistake, the squared distance to all of these **generously feasible** weight vectors is always decreased by **at least** the squared length of the update (input) vector (giảm một lượng ít nhất bằng với bình phương độ dài của vector đầu vào).
$\rightarrow$ The informal sketch of a proof of convergence:
1. Every time the perceptron makes a mistake, the **current** weight vector moves to decrease its squared distance from every weight vector in the **generously feasible** region (the **margin**)
2. The squared distance decreases **by** **at least** the squared length of the input vector and assuming that none of the input vectors are infinitesimally small (và giả thiết rằng không có vector đầu vào nào là nhỏ một cách vô hạn (nhỏ vô hạn)). That means:
3. After a finite number of mistakes, the weight vector must lie in the **feasible** region if this region exists. 
* Note: it doesn't have to lie in the **generously feasible** region, but it has to be into the **feasible** region to stop it making mistakes.
![Alt text](./1496670783420.png)
Giả sử đầu vào và trọng số là hữu hạn, chỉ bởi vì **một tập hợp đầu vào** có khu vực khả thi (không gian khả thi - khả nghiệm) không có nghĩa rằng (điều đó không có nghĩa rằng) chúng cũng có một không gian khả thi mở rộng.
### What perceptrons can't do - Limitations of perceptrons
1. For binary threshold neurons, an output unit cannot tell if two single bit feature are the same or not (XOR function):
		- Positive cases (same): $(1,1)\rightarrow1; (0,0)\rightarrow1$
		- Negative cases (different): $(1,0)\rightarrow0; (0,1)\rightarrow0$
		- The four input-output pairs give four inequalities that are impossible to satisfy: $$w_1+w_2\geq\theta, 0\geq\theta,$$ $$w_1<\theta, w_2<\theta$$
![Alt text](./1496673624516.png)
- A geometric view of limitations of binary threshold neurons:
![Alt text](./1496673693329.png)
Imagine "data-space" in which the axes correspond to components of an input vector.
- Each input vector is a point in the "input-data" space.
- A weight vector defines a plane in "data-space".
- The weight plane is perpendicular to the weight vector and misses the origin (cách gốc tọa độ) by a distance equal to the threshold.
For the above image, the positive and negative cases cannot be separated by **a plane**. Two data cases in green, we need to put an output of one, and two data cases in red, an output of zero.
![Alt text](./1496676481379.png)
![Alt text](./1496676525407.png)
2. A devastating example for perceptrons is more general is when trying and discriminating simple patterns that have to be retain the identity (giữ lại được đặc tính riêng biệt của chúng) when you translate them with wrap-around.
* Discriminating simple patterns under translation with wrap-around:
- want to recognize the simple pattern and want to recognize it even it's translated.
	- For example, suppose use pixels as features.
	- The question: can a binary threshold unit discriminate between different patterns that have the same number of **on** pixels? (one is positive example and other is negative example) $\rightarrow$ the answer is **no** if the discrimination have to work when the patterns are translated and if the patterns can wrap-around then translate.
![Alt text](./1496679641256.png)
![Alt text](./1496679837139.png)
$\rightarrow$ The perceptrons cannot discriminate (recognize) the classes (patterns) under translation if the wrap-around is allowed. Because a perceptron cannot learn to do if the transformations form a group (but translations with wrap-around form a group).
$\rightarrow$ To deal with, a perceptron need to use multiple feature units to recognize transformations of informative sub-patterns (the **tricky** part of pattern recognition must be solved by the hand-coded feature detectors, not the learning procedure).
$\rightarrow$ Learning with hidden units.
- To sum up, the limitations of perceptrons are:
	- The table look-up won't generalize. (Bảng tra cứu không tổng quát - XOR function).
	- Cannot recognize the patterns that their transformations form a group.
	- only consider to discriminate linearly.
- For hidden units:
	- more layers of linear units do not help (its still linear).
	- fixed output non-linearities are not enough.
$\rightarrow$ multiple layers of $\color{red}{adaptive}$, non-linear hidden units (the difficulty is how we can train such nets?)
	- need an efficient way of adapting **all** the weights, not just the last layer.
	- learning the weights going into hidden units = learning features (difficult since nobody tells directly what the hidden units should do and not should do).
# Week 3: Backpropagation algorithm - The backpropagation learning procedure
## Learning the weights of a linear neuron
### Why the perceptron learning procedure cannot be generalized to hidden layers
- The task of the perceptron convergence procedure is to ensure that every time, the weights change, they (the weights) get closer to every **generously** feasible set of weights.
$\rightarrow$ this type of guarantee cannot be extended to more complex networks (in which the average of two good solutions may be a bad solution).
- **multi-layer** neural networks do **not** use the perceptron learning procedure ($\rightarrow$ should **never** have been called multi-layer perceptrons). 
$\rightarrow$ a different way to make the learning procedure works.
### A different way to show that a learning procedure makes progress
- Instead of proofing the weights get closer to a good set of weights, show that the **actual** output values get closer to the **target** output values. 
- This has many advantages because of:
	- This can be true even for non-convex problems (in which there are many quite different sets of weights that work well and averaging two good sets of weights may give a bad set of weights (bad solution)) ($\leftarrow$ solving the limitation of perceptrons).
	- This learning is not true for perceptron learning.
- Let's explore the simplest example is a linear neuron with a squared error measure.
### Linear neurons (linear filters)
- is the neuron has the real-valued outputs which are the weighted sum of its inputs. (các giá trị đầu ra là số thực và các số thực này là tổng có tính trọng số của các giá trị đầu vào).
$$y=\sum_{i}w_ix_i=w^Tx$$
![Alt text](./1496748167149.png)
- The aim of learning is to **minimize** the error summed over all training cases with the error is the **squared difference** between the **desired** output and the **actual** output.   
- This problem can be solved by iterative solution or analytic solution (where to write down a set of equations, one equation per training case, and to solve for the best set of weights).
- But do **not** use analytic method, because of its relying on it (the analytic solution) being linear and having a squared error measure.
- Iterative methods are usually less efficient but they are much more easier to generalize (a method that real neurons could use and a method that can be generalized to multi-layer, non-linear neural networks).
- The iterative approach: Start with random guesses for the weights and then adjust the guesses **slightly** to give a better fit to the observed (actual) output given.

Question 1:
![Alt text](./1496756390860.png)
Question 2:
![Alt text](./1496757002325.png)
![Alt text](./1496757035164.png)
![Alt text](./1496757130858.png)
### Deriving the delta rule (with the purpose of changing weights slightly)
- The aim is to find the equation of $\Delta w_i$ per one training case.
	- Define the error as "the squared residuals summed over all training case".
$$E=\frac{1}{2}\sum_{n\in training}(t^n-y^n)^2$$
$t^n$: the target/actual/desired output value.
$y^n$: the estimated output value.
use $\frac{1}{2}$ to eliminate with the exponential factor ($2$) when taking derivative.
	- Differentiate to get error derivatives for weights (the partial derivative w.r.t weights).
$$\frac{\partial E}{\partial w_i}=\frac{1}{2}\sum_{n}\frac{\partial y^n}{\partial w_i}\frac{dE^n}{dy^n}\ (chain\ rule)$$ 
$$=-\sum_{n}x_i^n(t^n-y^n)$$
	-	The **batch** (one training case) delta rule changes the weights in proportion to (the learning rate $\epsilon$) their error derivatives **summed over all training cases**.
$$\Delta w_i=-\epsilon\frac{\partial E}{\partial w_i}=\sum_{n}\epsilon\ x_i^n(t^n-y^n)$$ 
### Behaviour of the iterative learning procedure
- Does the learning procedure eventually get the right answer?
	- may be no perfect solution.
	- making the learning rate ($\epsilon$) small enough $\rightarrow$ get as close as desiring to the best answer (solution).
- How quickly do the weights converge to their correct values?
	- It depends. 
	- It can be very slow if two input dimensions are highly correlated.   
### The relationship between the online delta-rule and the learning rule for perceptrons
| Perceptrons	|	Online delta-rule (the online version of the delta-rule)		|
|:--------------|:--------------------------|
|increment/decrement the weight vector by the input vector $\Delta w_i=\pm x$|increment/decrement the weight vector by the input vector scaled by the residual error and the learning rate $\Delta w_i=\epsilon\ x(t^n-y^n)$|
|only change when making an error||
||choose a learning rate|
## The error surface for a linear neuron
### The error surface in extended weight space
- The error surface lies in a space "with a horizontal axis" for each weight and "one vertical axis" for the error.
	- For a linear neuron with a squared error, it (the error surface) is a quadratic bowl. 
	- Vertical cross-sections are parabolas.
	- Horizontal cross-sections are ellipses.
![Alt text](./1496751744944.png)
Question:
![Alt text](./1496757556619.png)
![Alt text](./1496757577410.png)
- For multi-layer, non-linear nets, the error surface is much more complicated.
### Online versus batch learning
- From the error surface, getting the picture of what's happening as we do gradient descent learning using the delta rule. What the delta rule does is it computes the derivative of the error w.r.t the weights, and if changing the weights in proportion to that derivative, that's equivalent to doing steepest descent on the error surface.
- For error surface (which are elliptical contour lines), what the delta rule does is taking the right angles to those elliptical contour lines (perpendicular to).
$\rightarrow$ the batch learning (gradient in summed over **all** training cases).
- However, we could also do online learning (where after **each** training case, changing the weights in proportion to the gradient for that single training case) $\rightarrow$ much more like we did in perceptrons.
- The **change** in the weights moves towards one of these constraint planes (the blue line). 
- There are two training cases (in the right image). 
	- To get the first training case correct, must lie on the first blue line. And to get the second training case correct, must lie on the another blue line. 
	- Start with one of those red points, compute the gradient on the first training case, then the delta rule will move perpendicularly towards that line.
	- And with other training case, move perpendicularly towards the other line.
	- If alternative between the two training cases, zig-zag backwards and forwards, moving towards the solution point which is where those two lines intersect (where the set of weights that is correct for both training cases).
| The simplest kind of batch learning	| The simplest kind of online learning		|
|:--------------------------------------|------------------------------------------:|
| does steepest descent on the error surface (this travels perpendicular to the contour lines) - làm sụt giảm theo hướng có độ dốc dốc nhất, tức là hướng di chuyển vuông góc với các đường cong | zig-zags around the direction of steepest descent - zig-zag theo hướng sự sụt giảm là mạnh nhất (theo hướng có độ dốc dốc nhất)	|
|![The batch learning](./1496755692613.png)	| ![The online learning](./1496755714967.png)	|
### Why learning can be slow
- Condition that makes learning very slow: If the ellipse is very elongated (thuôn dài ở 2 cực của elip) (is happen when lines correspond to training cases is almost parallel), and when seeing in the gradient descent, the direction of steepest descent is almost perpendicular to the direction towards the minimum.
![Alt text](./1496759315714.png)
For the above image of the error surface, the red line is the gradient vector that has a long component along the short axis of the ellipse and a small component along the long axis of the ellipse. It means that, if we change each weight in proportion to the learning rate times the error derivative (in the simple steepest descent), it will towards the direction that the red gradient vector is longer, which is opposite of what we want (and is smaller in direction where we want to move a long way).
$\rightarrow$ the gradient quickly move across the narrow axis of the ellipse and will take a long time to take along the long axis of the ellipse (that is of what we don't want).

Question:
![Alt text](./1496759687957.png)
![Alt text](./1496759746198.png)
![Alt text](./1496759769620.png)
![Alt text](./1496759787827.png)
![Alt text](./1496759807949.png)
## Learning the weights of a logistic output neuron
- Aim: to extend the learning rule of linear output neurons to multi-layer nets of non-linear neurons, it is needed two steps:
	- extend the learning rule to a **single** non-linear neuron (use logistic neurons, besides there are many non-linear neurons instead).
	- central issue: learning rule of multiple layers of features.
### Logistic neurons
- Task: Generalize the learning rule of linear neuron to the non-linear (for example, logistic) neurons.
	- Logit $z$: $$z=b+\sum_{i}x_iw_i$$
	- Output $y$: $$y=\frac{1}{1+\exp(-z)}$$
$\rightarrow$ gives a real-valued output that is a smooth and bounded function of the total input.
$\rightarrow$ having nice derivatives which make learning easy.

Question:
![Alt text](./1496767607523.png)
- The derivatives of a logistic neuron:
	- The derivatives of the logit $z$ w.r.t. the inputs and the weights are:
$$z=b+\sum_{i}x_iw_i$$
$$\frac{\partial z}{\partial w_i}=x_i,\ \frac{\partial z}{\partial x_i}=w_i$$
	- The derivative of the output $y$ w.r.t. the logit $z$ is:
$$y=\frac{1}{1+e^{-z}}$$
$$\frac{dy}{dz}=y(1-y)$$
![Alt text](./1496764849032.png)
	- Using the chain rule to get the derivatives needed for learning the weights of a logistic unit (because we consider the **single** non-linear neuron)
		- To learn the weights, need the derivative of the output $y$ w.r.t. each weight $w_i$
$$\frac{\partial y}{\partial w_i}=\frac{dy}{dz}\frac{\partial z}{\partial w_i}=y(1-y)\ x_i$$
$$\rightarrow \frac{\partial E}{\partial w_i}=\sum_{n}\frac{\partial y^n}{\partial w_i}\frac{\partial E}{\partial y^n}=-\sum_{n}y^n(1-y^n)\ x_i^n\ (t^n-y^n)$$
![Alt text](./1496767509398.png)
$\rightarrow$ the derivative of the output $y$ of the single logistic neuron w.r.t. each weight $w_i$ is minus the sum of all the row of training cases and of the value on input line $x_i^n$ times the residual (the difference) between the target and the output (on the actual output of the neuron), with **the extra term** which is come from the slope of the logistic function (that is $y^n(1-y^n)$) 
$\rightarrow$ a slight modification of the delta rule gives the gradient descent learning rule for training a logistic unit.
## The backpropagation algorithm
### Learning by perturbing (nhiễu loạn) weights (not work very well)
1. Overview
- the idea is based on the evolution or is a form of reinforcement learning (học theo cách cải thiện, tiến triển).
- randomly perturb (nhiễu loạn) one weight and see if it improves performance. If so, save the change.
- actions: making the small change and checking whether that pays off. If it does, decide to perform that action.
2. Discuss
- Disad: very inefficient.
$\rightarrow$ Reason: To make a change of each weight, need to do multiple forward passes on a **representative set of training cases**. Then, have to see if changing that weight improves things, and **can't** judge that by **one** training case alone.
- Relative to this method of randomly changing weight, and seeing if it helps, the backpropagation is much more efficient, usually more efficient by a factor of the number of weights in the network (could be millions).
- 2nd disad (another problem with randomly changing weights and seeing if it helps) is that: towards the end of learning, any large change in weight perturbations will nearly always make things **worse** (because the weights have to have the right relative values to work properly)   
$\rightarrow$ towards the end of learning not only do you have to do a lot of work to decide whether each of these changes helps but also the changes themselves have to be very small. 
![Alt text](./1496784485181.png)
3. Improvement for perturbations of weights to learn
- randomly perturb all the weights **in parallel** and then correlate the performance gain with the weight changes.  
$\rightarrow$ not better at all, because need to do lots of trials on each training case with different random perturbation of all the weights, in order to "see" the effect of changing one weight through the noise created by all the changing of the other weights.
- another better idea: randomly perturb the **activities** of the hidden units, instead of perturbing the **weight**. Once decided that perturbing the activity of a hidden unit on a particular training case, then can **compute** how to change the weights. Since there are many fewer activities than weights, there's less things that randomly exploring $\rightarrow$ the algo makes more efficient, makes better.
- **BUT** those approaches are still much less efficient than **backpropagation**. Backpropagation still wins by a factor of the number of neurons.

Question:
![Alt text](./1496832116651.png)
![Alt text](./1496832134737.png)
### The idea behind backpropagation
- Cause: don't know what the hidden units ought to do (hidden units = don't know what their states are), but can compute **how fast** the error changes as changing a hidden activity on a particular training case.
$\rightarrow$ instead of using activities of the hidden units as the desired states to train the hidden units, use **the error derivatives w.r.t. hidden activities** $\frac{\partial error}{\partial hidden\ activities}$.
- Since each hidden activity affect many output units, then, therefore, have many separate, different effects on the error and these effects can be combined.
- With backpropagation, can compute the error derivatives for **all** hidden units **at the same time**.
$\rightarrow$ once have known the error derivatives w.r.t. hidden activities, it's easier to get the error derivatives w.r.t. weights going into a hidden unit.

Question:
![Alt text](./1496833261969.png)
### Sketch of the backpropagation algo on a single case
- Step 1: Write the error equation and compute the error derivative w.r.t. the output 
$$E=\frac{1}{2}\sum_{j\ \in\ training}(t_j-y_j)^2$$ for all training cases ($j \in training$)
with $t_j$: the target output, $y_j$: the actual output for a single training case.
$$\frac{\partial E}{\partial y_j}=-(t_j-y_j)$$
- Step 2: Compute error derivatives in each hidden layer from error derivatives in the layer **above**.
![Alt text](./1496838802691.png)
![Alt text](./1496838884585.png)
For current layer, denote that layer is with index $j$ (above), the previous layer with index $i$ (below). The $y_j$ is the output of layer $j$, $y_i$ is the output of layer $i$, $z_j$ is the logit coming into the layer $j$
We want to compute the backpropagation $\frac{dE}{dy}$ for previous layer $i$
For layer $j$: The error derivative w.r.t. the **activity** of layer $j$
$$\frac{\partial E}{\partial z_j}=\frac{dy_j}{dz_j}\frac{\partial E}{\partial y_j}=y_j(1-y_j)\frac{\partial E}{\partial y_j}=-y_j(1-y_j)(t_j-y_j)$$
For layer $i$: The error derivative w.r.t. the **output** of layer $i$
$$\frac{\partial E}{\partial y_i}=\sum_{j}\frac{dz_j}{dy_i}\frac{\partial E}{\partial z_j}=\sum_{j}w_{ij}\frac{\partial E}{\partial z_j}$$
- Step 3: Use error derivatives w.r.t. **activities** to get error derivatives w.r.t. the **incoming weights**.
$\rightarrow$ The error derivative w.r.t. the **weights** coming from layer $i$ to layer $j$ $$\frac{\partial E}{\partial w_{ij}}=\frac{\partial E}{\partial z_j}\frac{dz_j}{dw_{ij}}=\frac{\partial E}{\partial z_j}y_i$$
$\rightarrow$ From **current** layer, we use the error derivatives w.r.t. **activities** and **output** of this layer in order to compute the error derivatives w.r.t. **output** of the **previous** layer, and then obtain the error derivatives w.r.t the **weights** coming from previous layer to current layer.
### How to use the derivatives computed by the backpropagation algo
1. Converting error derivatives into a learning procedure
- The backpropagation algo is an efficient way of computing the error derivative $\frac{dE}{dw}$ for **every** weight on a **single** training case. (it is not learning algo $\rightarrow$ need to do number of other things to get a proper learning procedure)
- To get a fully specified learning procedure, need to make a lot of other decisions about how to use these error derivatives: Some of these decisions are: 
		- Optimization issues: How to use the error derivatives on **individual** cases to discover a good **set** of weights? ($\color{red}{Lecture\ 6}$). (about how going to optimize?)
		- Generalization issues: How to ensure that the **learned weights** work **well** for cases did **not** be **seen** during training? ($\color{red}{Lecture\ 7}$). (how to ensure that the weights that are learned will generalize well)
- Now, a brief overview of these two sets of issues is introduced.
2. Optimization issues in using the weight derivatives (how to use the weight derivatives)
- How **often** to update the weights? (Methods of updating weights)
		- Online: after **each** training case. (compute the error derivatives on a training case using backpropagation and then make a small change to the weights) $\rightarrow$ zig-zag case because of different error derivatives on different training case, but on average, if make the weight changes small enough, it will go in the right direction.  
		- Full batch: after **a full sweep** through the training data. (more sensible to use full batch training where doing a full sweep through all of the training data and adding together all of the error derivatives that is gotten on the individual cases, then making a small step in that direction) (a problem is that if starting off with a bad set of weights and having a very big training set, we don't want to do all that work of going through the whole training case in order to fix up some weights that we know are pretty bad)
		- Mini-batch: after **a small sample** of training cases. (taking small random sample of training cases and going in that direction) (really only need to look at a few training cases before getting a reasonable idea of what direction we want to move the weights in $\rightarrow$ don't need to look at a large number of training cases until we get towards the end of learning) (a little bit of zig-zagging, not nearly as much zig zagging as if in online learning where using one training case at a time) (usually used in training big neural networks on big data sets)
- How **much** to update (more in $\color{red}{Lecture\ 6}$) (how big a change we make)
		- Use a fixed learning rate? (just by hand try and pick some fixed learning rate, then learn the weights by changing each weight by the derivative that is computed times that learning rate = $\frac{\partial E}{\partial w}\times\delta$)
		- Adapt the global learning rate? (more sensible to adapt the learning rate = oscillating around, if the error keeps going up and down, then reduce the learning rate, but if we're making steady progress, might increase the learning rate)
		- Adapt the learning rate on each connection separately? (so that some weights learn rapidly and other weights learn more slowly)
		- Don't use steepest descent (hướng có độ dốc dốc nhất)? (if we had a very elongated (giãn dài) ellipse, we see that the direction of the steepest descent is almost at wrong angles to the direction to the minimum that we want to find) (typically, towards the end of learning, of most learning problems, so there's much better directions to go in than the direction of steepest descent)
Question:
![Alt text](./1497291969286.png)
![Alt text](./1497291997561.png)
![Alt text](./1497292025307.png)
![Alt text](./1497292058414.png)
Explanation:
Offline learning trying to optimize with respect to all entire of training data, so it directly minimize the total error while online learning just is done in each data example, so it minimize a different error that approximately the total error $\rightarrow$ not stable.
3. Overfitting: The downside of using powerful models
- The training data **contains** information about the regularities in the mapping from input to output. But it also contains **two** types of noise:
		- The target values may be **unreliable** (a minor worry).
		- There is **sampling error** (There will be accidental regularities (những quy tắc do sự cố, do vô tình, do tai nạn, do ngẫu nhiên chủ quan) just because of the particular training cases that were chosen).
- When fitting the model, it cannot tell which regularities (những quy tắc) are real and which are caused by **sampling error**.
		- $\rightarrow$ fitting both kinds of regularity.
		- If the model is very flexible, it can model the sampling error really well (nếu có một mô hình rất linh hoạt, mô hình này có thể mô hình các lỗi lấy mẫu một cách rất tốt, rất hiệu quả) $\rightarrow$ this is a disaster (thảm họa).
Question:
![Alt text](./1497294204937.png)
![Alt text](./1497294235950.png)
![Alt text](./1497294359228.png)
- Way to reduce overfitting: (How to prevent the network from overfitting very badly if use the large network)
	- weight-decay (try and keep the weights of the networks small, try and keep many of the weights at 0, idea: make the model simpler)
	- weight-sharing (make the model simpler by insisting that many of the weights have exactly the same value as each other, $next\ lecture$, how weight-sharing is used)
	- early stopping (peek at a fake test set while training and stop when performance gets decent)
	- model averaging (train lots of different neural nets, and average them together in the hopes that will reduce the errors)
	- Bayesian fitting of neural nets (just a fancy form of model averaging)
	- dropout (try and make the model more robust by randomly emitting hidden units when training it)
	- generative pre-training (more complicated) ($end\ of\ the\ course$)
$\rightarrow$ more detail in $\color{red}{Lecture\ 7}$
# Week 4: Learning feature vectors for words
## 4.1. Learning to predict the next word



 
 















     
