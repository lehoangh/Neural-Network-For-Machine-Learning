# Week 6: Overview of mini-batch gradient descent
[TOC]
- mini-batch gradient descent = stochastic gradient descent
## 6.1. Reminder: The error surface for a linear neuron
- The error surface for a linear neuron means the surface that lies in a space where the horizontal axes correspond to the weights of the neural net and the vertical axis corresponds to the error this neural net makes.
	- Example: for a linear neural net with the squared error, the error surface always forms a quadratic bowl.
	- In 2D projection space, the vertical cross-sections are parabolas.
![Alt text](./1506965187994.png)
	- In 2D projection space, the horizontal cross-sections are ellipses.
![Alt text](./1506965280147.png)
- For multi-layer, non-linear nets, the error surface is much more complicated. However, as long as the weights aren't too big, it's a smooth error surface, and locally, it is approximated by a fraction of a quadratic bowl. It might not be the bottom of the bowl but there is a piece of quadratic bowl that will fit the local error surface very well.
### 1. Convergence speed of full batch learning when the error surface is a quadratic bowl       
- Consider the convergence speed of the full-batch learning and the error surface is a quadratic bowl, if we go downhill, this will reduce the error.
- BUT the problem is that the direction of steepest descent does not point at the minimum unless the ellipse is a circle.
	- For the ellipse, the gradient is big in the direction where we only want to travel a small distance.
	- The gradient is small in the direction in which we want to travel a large distance.
	$\rightarrow$ it is precisely the wrong way around. $\rightarrow$ slow convergence speed.
	- This problem is also increasing for non-linear multi-layer nets (the error surface is locally quadratic).
### 2. How the learning goes wrong
- If the learning rate is big, the weights are zig-zag in the error surface.
- If the **too big** learning rate, this oscillation diverges.
![Alt text](./1506972459999.png)
- What we want to achieve:
	- move quickly in directions with small but consistent gradients. 
	- move slowly in directions with big but inconsistent gradients. (that is going in the direction with short distance and the gradient is reversed sign).
### 3. Stochastic gradient descent (SGD)
- The motivation of using SGD:
	- If the dataset is highly redundant, compute the gradient for a weight on the first half is almost the same as that of the second half.
	$\rightarrow$ complete waste of time to compute the gradient on the whole dataset.
	$\rightarrow$ computing the gradient on a subset of the data, then updating the weights and on the remaining data, computing the gradient for the updated weights.
	- It means that: instead of computing the full gradient, update the weights using the gradient on the first half and then get a gradient for the new weights (the updated weights) on the second half.
	- The extreme version of this approach weights update is that updating after each case. Its called **online**.
		- on the single training sample, compute its gradient and update the weight, then computing the gradient on the next training case using those new weights (updated weights).
	-	The better choice is the small mini-batches (than online case), typically is 10, 100 or 1000 examples with some advantages:
			- less computation is used for updating the weights, compared to online.
			- when computing the gradient, compute gradients for a whole bunch of cases in parallel (for many cases simultaneously) using matrix-matrix multiplies which are very efficient, especially on GPUs.
- One problem with mini-batches is that we don't want to have a mini-batch in which the answer is always the same and then on the next mini-batch have a different answer that's always the same.
	- Example: if you have 10 classes and you want to have a mini-batch of 10 examples or 100 examples that has exactly the same number from each class in the mini-batch.   
$\rightarrow$ the training examples need to be sampled in a way that they are to be approximated, which is simply to take all data and just put it in random order and grab randomly mini-batches. But must avoid the mini-batches that are very uncharacteristic of the whole set of data because the mini-batches are all of one class. Mini-batches need to be balanced (full distribution) for classes.
### 4. Two types of learning algorithm
- full gradient algo, computing the gradient from all the training cases.
	- when it is done, there is a lot of clever ways to speed up learning (e.g. non-linear conjugate gradient).
- mini-batch learning when the training set is very large and highly redundant.
	- the mini-batch can be very big when adapting fancy methods, but that's not so bad because big mini-batches are more computationally efficient.
* Quiz in lecture video:
![Alt text](./1506975376437.png)
### 5. A basic mini-batch gradient descent algorithm
- Training a big neural net on a big redundant dataset.
- Steps:
	- Guess an initialization of learning rate, and look to see:
		- if the error keeps getting worse (oscillates wildly), reduce the learning rate.
		- if the error is falling fairly consistenly but too slowly, increase the learning rate.
	- Write a simple program to automate this way of adjusting the learning rate.
	- One thing that nearly always helps is, towards the end of learning with mini-batches, it helps to turn down the learning rate.
		- because that getting fluctuations in the weights caused by the fluctuations in the gradients that come from the mini-batches. Therefore, turn down the learning rate, can remove (smooth away) those fluctuations and getting the final set of weights that's good for many mini-batches.
	- When turn down the learning rate? is when the error stops decreasing.
		- A good criterion for saying the error stopped decreasing is to use the error on a separate validation set.
## 6.2. A bag of tricks for mini-batch gradient descent
### 1. The problem of turning down the learning rate           
 